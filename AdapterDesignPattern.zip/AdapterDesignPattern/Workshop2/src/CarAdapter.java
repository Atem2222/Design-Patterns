// CarAdapter.java
//Design Patterns
// Assignment 2
//Written by Atem Ako, Kasra Bina, Arian Abedanzadeh
//Last Modified : 3rd October 2024
public class CarAdapter implements Vehicle {
    private Car car;

    public CarAdapter(Car car) {
        this.car = car;
    }

    @Override
    public void addFuel(double amount) {
        car.carAddFuel(amount);
    }
    @Override
    public double getTime() {
        return  car.getCarTime();
    }
    @Override
    public void travel(double distance) {
        car.carTravel(distance);
    }

    @Override
    public double getDistance() {
        return car.getCarDistance();
    }

    @Override
    public double getFuelLevel() {
        return car.getCarFuelLevel();
    }

    @Override
    public double getFuelCost() {
        return car.getCarFuelCost();
    }
}
