// TravelSimulation.java
//Design Patterns
// Assignment 2
//Written by Atem Ako, Kasra Bina, Arian Abedanzadeh
//Last Modified : 3rd October 2024
class TravelSimulation {
    public static void main(String[] args) {
        // the boat travels 100km and information about the boat is printed
        // Initialize vehicles
        Car car = new Car();
        Boat boat = new Boat();
        Airplane airplane = new Airplane();

        // Wrap them with their adapters
        Vehicle carAdapter = new CarAdapter(car);
        Vehicle boatAdapter = new BoatAdapter(boat);
        Vehicle airplaneAdapter = new AirplaneAdapter(airplane);

        boatAdapter.travel(100.0);
        VehicleUtility.printVehicleInformation(boatAdapter, "Boat");

        // the car travels 1000km and information about the car is printed
        carAdapter.travel(1000.0);
        VehicleUtility.printVehicleInformation(carAdapter, "Car");

        // the airplane travels 10000km and information about the airplane is printed
        airplaneAdapter.travel(10000.0);
        VehicleUtility.printVehicleInformation(airplaneAdapter, "Airplane");

        // Add fuel to each
        System.out.println();
        System.out.println("Adding fuel...");
        System.out.println();

        boatAdapter.addFuel(120);
        carAdapter.addFuel(40);
        airplaneAdapter.addFuel(50000);

        // Travel again
        // Boat
        boatAdapter.travel(100.0);
        VehicleUtility.printVehicleInformation(boatAdapter, "Boat");

        // Car
        carAdapter.travel(1000.0);
        VehicleUtility.printVehicleInformation(carAdapter, "Car");

        // Airplane
        airplaneAdapter.travel(10000.0);
        VehicleUtility.printVehicleInformation(airplaneAdapter, "Airplane");

        new java.util.Scanner(System.in).nextLine();
    }
}