// Vehicle.java
//Design Patterns
// Assignment 2
//Written by Atem Ako, Kasra Bina, Arian Abedanzadeh
//Last Modified : 3rd October 2024
public interface Vehicle {
    void addFuel(double amount);
    void travel(double distance);
    double getTime();
    double getDistance();
    double getFuelLevel();
    double getFuelCost();
}
