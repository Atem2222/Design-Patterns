// VehicleUtility.java
//Design Patterns
// Assignment 2
//Written by Atem Ako, Kasra Bina, Arian Abedanzadeh
//Last Modified : 3rd October 2024
public class VehicleUtility {
    public static void printVehicleInformation(Vehicle vehicle, String vehicleType) {
        System.out.println("Vehicle Type: " + vehicleType);
        System.out.println("Travel Distance: " +  vehicle.getDistance() + "km");
        System.out.println("Travel Time: " + vehicle.getTime()+ " hours");
        System.out.println("Current Fuel Level: " + vehicle.getFuelLevel() + "L");
        System.out.println("Fuel Cost: $" + vehicle.getFuelCost());
        System.out.println();
    }
}