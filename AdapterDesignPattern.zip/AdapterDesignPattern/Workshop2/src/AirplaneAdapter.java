// AirplaneAdapter.java
//Design Patterns
// Assignment 2
//Written by Atem Ako, Kasra Bina, Arian Abedanzadeh
//Last Modified : 3rd October 2024
public class AirplaneAdapter implements Vehicle{
    private Airplane airplane;

    public AirplaneAdapter(Airplane airplane) {
        this.airplane = airplane;
    }

    @Override
    public void addFuel(double amount) {
        airplane.airplaneAddFuel(amount);
    }
    @Override
    public double getTime() {
     return  airplane.getAirplaneTime();
    }
    @Override
    public void travel(double distance) {
        airplane.airplaneTravel(distance);
    }

    @Override
    public double getDistance() {
        return airplane.getAirplaneDistance();
    }

    @Override
    public double getFuelLevel() {
        return airplane.getAirplaneFuelLevel();
    }

    @Override
    public double getFuelCost() {
        return airplane.getAirplaneFuelCost();
    }
}
