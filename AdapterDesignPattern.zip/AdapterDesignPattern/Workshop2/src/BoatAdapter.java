// BoatAdapter.java
//Design Patterns
// Assignment 2
//Written by Atem Ako, Kasra Bina, Arian Abedanzadeh
//Last Modified : 3rd October 2024
public class BoatAdapter implements Vehicle{
    private Boat boat;

    public BoatAdapter(Boat boat) {
        this.boat = boat;
    }

    @Override
    public void addFuel(double amount) {
        boat.boatAddFuel(amount);
    }
    @Override
    public double getTime() {
        return  boat.getBoatTime();
    }
    @Override
    public void travel(double distance) {
        boat.boatTravel(distance);
    }

    @Override
    public double getDistance() {
        return boat.getBoatDistance();
    }

    @Override
    public double getFuelLevel() {
        return boat.getBoatFuelLevel();
    }

    @Override
    public double getFuelCost() {
        return boat.getBoatFuelCost();
    }
}
